package api

// APIKeyHeader in this header thr right api key should be inserted
const APIKeyHeaderKey = "apikey"

// TenantHeaderKey in this header thr right api key should be inserted
const TenantHeaderKey = "tenant"
