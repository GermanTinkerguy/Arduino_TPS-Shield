package unittestexample


func Sum(x int, y int) int {
	return x + y
}

