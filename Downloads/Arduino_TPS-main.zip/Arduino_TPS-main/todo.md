TODO for the TPS



- switch to the new TM1637-1.2.0 lib. Colon defining is now different.

