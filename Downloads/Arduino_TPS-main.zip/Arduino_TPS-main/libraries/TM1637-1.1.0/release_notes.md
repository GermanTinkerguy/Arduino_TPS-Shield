- V1.1.0
  * Add support for decimal points/colon
  * Minor fixes
  
- V1.0.0
  * Initial release

